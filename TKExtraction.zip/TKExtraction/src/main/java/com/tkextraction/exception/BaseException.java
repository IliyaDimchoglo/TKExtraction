package com.tkextraction.exception;

import lombok.Getter;

@Getter
public class BaseException extends RuntimeException {

    private final String title;
    private final String key;

    public BaseException(String title, String message, String key) {
        super(message);
        this.title = title;
        this.key = key;
    }
}