package com.tkextraction.service;

import com.tkextraction.domain.dto.RetrieveResponse;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

public interface ExtractionService {

    @Transactional
    Long submit(String userName, MultipartFile file);

    @Transactional
    RetrieveResponse retrieve(String userName, Long processId);
}
