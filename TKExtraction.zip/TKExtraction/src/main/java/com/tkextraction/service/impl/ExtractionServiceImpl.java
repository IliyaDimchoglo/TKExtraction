package com.tkextraction.service.impl;

import com.tkextraction.domain.CVEntity;
import com.tkextraction.domain.UserEntity;
import com.tkextraction.domain.dto.CompletedResponse;
import com.tkextraction.domain.dto.InProgressResponse;
import com.tkextraction.domain.dto.RetrieveResponse;
import com.tkextraction.domain.enums.Status;
import com.tkextraction.repository.UserRepository;
import com.tkextraction.service.ExtractionService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import static com.tkextraction.utils.TransactionRandomizer.getRandomIdTransaction;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExtractionServiceImpl implements ExtractionService {

    private final UserRepository userRepository;

    @Override
    @SneakyThrows
    public Long submit(String userName, MultipartFile file) {
        UserEntity user = userRepository.findByUserName(userName);
        final Long processId = getRandomIdTransaction();
        user.setCv(new CVEntity(user, processId));
        user.getCv().runAsyncUpdateCVSourceAndStatus(file);
        log.info("[x] process id: {}", processId);
        return processId;
    }

    @Override
    public RetrieveResponse retrieve(String userName, Long processId) {
        UserEntity user = userRepository.findByUserNameAndCvProcessId(userName, processId);
        if(user.getCv().getProcessStatus().equals(Status.PROGRESS)){
            log.info("[x] CV in progress for submit, userName: {} ", userName);
            return new InProgressResponse();
        } else {
            log.info("[x] CV submitted, userName: {} ", userName);
            return CompletedResponse.of(user.getCv().getCvSource());
        }
    }
}
