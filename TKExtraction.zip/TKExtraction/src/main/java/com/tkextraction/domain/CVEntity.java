package com.tkextraction.domain;


import com.tkextraction.domain.enums.Status;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.*;

@Slf4j
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "cv")
@EqualsAndHashCode(callSuper = true)
public class CVEntity extends BaseUpdatedEntity {

    @MapsId
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private UserEntity user;

    @Enumerated(EnumType.STRING)
    private Status processStatus;

    @Column(nullable = false)
    private Long processId;

    @Lob
    @Column(name = "cv_source_blob")
    private byte[] cvSource;

    public CVEntity(UserEntity user, Long processId) {
        this.user = user;
        this.processId = processId;
        this.processStatus = Status.PROGRESS;
    }

    @Async
    @Transactional
    @SneakyThrows
    public void runAsyncUpdateCVSourceAndStatus(MultipartFile file){
        log.info("[x] start async cv progress");
        processStatus = Status.COMPLETED;
        cvSource = file.getBytes();
    }
}
