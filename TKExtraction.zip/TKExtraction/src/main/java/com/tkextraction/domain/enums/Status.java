package com.tkextraction.domain.enums;

public enum Status {
    PROGRESS, COMPLETED
}
