package com.tkextraction.domain.dto;


public interface RetrieveResponse {
}
