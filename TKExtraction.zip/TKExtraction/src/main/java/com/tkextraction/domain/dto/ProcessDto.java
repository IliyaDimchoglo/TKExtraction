package com.tkextraction.domain.dto;

import lombok.Value;

@Value(staticConstructor = "of")
public class ProcessDto {
     Long processId;
}
