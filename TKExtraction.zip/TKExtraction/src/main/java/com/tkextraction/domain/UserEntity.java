package com.tkextraction.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user_entity")
@EqualsAndHashCode(callSuper = true)
public class UserEntity extends BaseUpdatedEntity {

    @Column(nullable = false, unique = true)
    private String userName;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "user", fetch = FetchType.LAZY)
    private CVEntity cv;

    public UserEntity(String userName) {
        this.userName = userName;
    }
}
