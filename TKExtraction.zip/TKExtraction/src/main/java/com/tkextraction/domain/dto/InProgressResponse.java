package com.tkextraction.domain.dto;

import com.tkextraction.domain.enums.Status;
import lombok.Value;


@Value
public class InProgressResponse implements RetrieveResponse {
    Status status = Status.PROGRESS;
}
