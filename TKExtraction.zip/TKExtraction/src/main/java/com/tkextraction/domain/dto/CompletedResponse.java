package com.tkextraction.domain.dto;

import lombok.Value;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Value(staticConstructor = "of")
public class CompletedResponse implements RetrieveResponse {

    @XmlJavaTypeAdapter(HexBinaryAdapter.class)
    @XmlElement(name = "xml")
    byte[] source;
}
