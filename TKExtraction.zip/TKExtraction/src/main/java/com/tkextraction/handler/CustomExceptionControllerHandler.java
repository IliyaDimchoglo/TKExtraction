package com.tkextraction.handler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;

@Slf4j
@ControllerAdvice
public class CustomExceptionControllerHandler {

   /* @ExceptionHandler(Throwable.class)
    public ResponseEntity<RuntimeException> defaultExceptionHandler(final Throwable ex) {
        log.error(Arrays.toString(ex.getStackTrace()));
        return ResponseEntity.badRequest().body(new RuntimeException("[x] Something went wrong"));
    }*/
}