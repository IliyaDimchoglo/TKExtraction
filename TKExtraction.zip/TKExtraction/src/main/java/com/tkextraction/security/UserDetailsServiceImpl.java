package com.tkextraction.security;

import com.tkextraction.domain.UserEntity;
import com.tkextraction.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) {
        UserEntity user = userRepository.findByUserName(username);
        if(Objects.isNull(user)) {
            log.info("[x] new user logged in with name: {}", username);
            userRepository.save(new UserEntity(username));
        }
        return new CustomUserDetails(username, "password");
    }
}
