package com.tkextraction.repository;

import com.tkextraction.domain.CVEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CVRepository extends JpaRepository<CVEntity, UUID> {

}
