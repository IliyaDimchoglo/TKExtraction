package com.tkextraction.repository;

import com.tkextraction.domain.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface UserRepository extends JpaRepository<UserEntity, UUID> {

    UserEntity findByUserName(String userName);

    UserEntity findByUserNameAndCvProcessId(String userName, Long processId);
}
