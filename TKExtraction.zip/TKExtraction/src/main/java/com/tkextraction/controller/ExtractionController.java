package com.tkextraction.controller;

import com.tkextraction.domain.dto.ProcessDto;
import com.tkextraction.domain.dto.RetrieveResponse;
import com.tkextraction.service.ExtractionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotNull;
import java.security.Principal;

@RestController
@RequestMapping(value = "/cv")
@RequiredArgsConstructor
public class ExtractionController {

    private final ExtractionService extractionService;

    @PostMapping(value = "/submit")
    public ResponseEntity<ProcessDto> submit(@RequestParam(name = "file") @NotNull MultipartFile file, Principal principal) {
        return ResponseEntity.ok(ProcessDto.of(extractionService.submit(principal.getName(), file)));
    }

    @GetMapping(value = "/retrieve", produces = MediaType.TEXT_XML_VALUE)
    public ResponseEntity<RetrieveResponse> retrieve(@RequestParam(name = "processId") Long processId, Principal principal) {
        return ResponseEntity.ok(extractionService.retrieve(principal.getName(), processId));
    }
}
